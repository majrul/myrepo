package com.jpmc.training.day1.basics;

public class Employee {

    //member variables, instance variables, fields
    private int empno;
    private String name;
    private double salary;

    //constructor(s)
    public Employee() { //default constructor
    }
    public Employee(int empno, String name, double salary) {
        this.empno = empno;
        this.name = name;
        this.salary = salary;
    }

    //getters & setters - properties
    public int getEmpno() {
        return empno;
    }

    public void setEmpno(int empno) {
        this.empno = empno;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void newEmployeeJoins() {
        sendImportantDocuments();
        updateDatabase();
    }

    public void sendImportantDocuments() {
        //code for sending en email to the emp
    }

    public void updateDatabase() {
        //code for storing employee data in some database
    }

}
