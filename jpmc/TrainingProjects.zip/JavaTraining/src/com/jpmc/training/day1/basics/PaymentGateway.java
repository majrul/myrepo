package com.jpmc.training.day1.basics;

public class PaymentGateway {

    public void processOnlinePayment(PaymentDetails paymentDetails) {
        PaymentStore paymentStore = new PaymentStore();
        paymentStore.storePaymentDetails(paymentDetails);

        TransactionProcessor transactionProcessor = new TransactionProcessor();
        transactionProcessor.communicateWithBank(paymentDetails);

    }
}
