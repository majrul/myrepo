package com.jpmc.training.day1.basics;

public class PaymentStore {

    public void storePaymentDetails(PaymentDetails paymentDetails) {
        System.out.println("Payment Details stored in the db successfully..");
    }
}
