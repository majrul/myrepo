package com.jpmc.training.day1.basics;

public class PhoneBook {

    //private String[] name;
    //private String[] number;
    //private String[] email;

    private String name;
    private Entry[] entries;
    private int count;

    public PhoneBook() {
        this.name = "My PhoneBook";
        this.entries = new Entry[100];
    }

    public PhoneBook(String name, int noOfEntries) {
        this.name = name;
        this.entries = new Entry[noOfEntries];
    }

    public void add(String name, String number, String email) {
        Entry e = new Entry(name, number, email);
        entries[count++] = e;
    }

    public Entry search(String email) {
        for(int i=0;i<count;i++)
            if(entries[i].getEmail() == email)
                return entries[i];
        return null; //throw exception instead
    }

    public void display() {
        System.out.println("Details of " + name + " v1.0");
        for(int i=0; i<count; i++)
            System.out.println(entries[i].getName() + " , " +entries[i].getNumber() +" , " + entries[i].getEmail());
    }
}
