package com.jpmc.training.day1.basics;

public class TestCalculator {

    public static void main(String[] args) {
        Calculator c = new Calculator();
        c.add(10, 20);
        c.sub(10, 20);
        //Calculator.add(10,20);
        //Calculator.sub(10,20);

    }
}
