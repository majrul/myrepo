package com.jpmc.training.day1.basics;

public class TestEmployee {

    public static void main(String[] args) {
        Employee e1 = new Employee(1111,"Majrul",1000);

        Employee e2 = new Employee();
        e2.setEmpno(222);
        e2.setName("John");
        e2.setSalary(4500);

        System.out.println(e1.getEmpno() + " , " + e1.getName() + " , " + e1.getSalary());
        System.out.println(e2.getEmpno() + " , " + e2.getName() + " , " + e2.getSalary());

        e1.newEmployeeJoins();
        e2.newEmployeeJoins();

    }
}
