package com.jpmc.training.day1.basics;

public class TestPaymentGateway {
    public static void main(String[] args) {
        PaymentDetails paymentDetails = new PaymentDetails();
        paymentDetails.setCustomerId("C1-123");
        paymentDetails.setBankId("ICICI");
        paymentDetails.setAmount(5000);

        PaymentGateway paymentGateway = new PaymentGateway();
        paymentGateway.processOnlinePayment(paymentDetails);
    }
}
