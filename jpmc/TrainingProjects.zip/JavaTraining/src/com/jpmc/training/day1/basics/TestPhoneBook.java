package com.jpmc.training.day1.basics;

public class TestPhoneBook {

    public static void main(String[] args) {
        PhoneBook phBook = new PhoneBook("My Friends", 10);
        phBook.add("Amar", "9191919191","amar@friends.com");
        phBook.add("Akbar", "9191919191","akbar@friends.com");
        phBook.add("Anthony", "9191919191","anthony@friends.com");

        phBook.display();

        System.out.println("Search Result:");
        Entry e = phBook.search("anthony@friends.com");
        if(e != null)
            System.out.println(e.getName() + " , " + e.getNumber() + " , " + e.getEmail());
    }
}
