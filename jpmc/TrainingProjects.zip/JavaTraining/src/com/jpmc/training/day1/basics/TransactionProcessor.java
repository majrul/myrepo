package com.jpmc.training.day1.basics;

public class TransactionProcessor {

    public void communicateWithBank(PaymentDetails paymentDetails) {
        System.out.println("Communication with the bank successful!");
    }
}
