package com.jpmc.training.day2;

public class Stringham {

    public static void main(String[] args) {
        String s1 = "Java"; //1 kept in the pool
        String s2 = new String("Java"); //2 //no need to use new keyword
        String s3 = "Java"; //1 referred from the pool
        String s4 = new String("Java"); //3

        System.out.println(s1 == s3); //reference comparison
        System.out.println(s2 == s4); //reference comparison
        System.out.println(s2.equals(s4)); //value comparison

        String s5 = "JAVA"; //kept in the pool
        //String s6 = s1.toUpperCase(); //not kept in the pool
        String s6 = s1.toUpperCase().intern();
        System.out.println(s5 == s6);

        String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        // ----------- string concatenation comparison --------------- //
        String newStr = "";
        long ms1 = System.currentTimeMillis();
        for(int i=0; i<str.length(); i++)
            for(int j=0; j<=i; j++)
                newStr = newStr + str.charAt(j);
        long ms2 = System.currentTimeMillis();

        System.out.println("approx time taken : " + (ms2 - ms1) + " ms");
        System.out.println(newStr);

        // ---------- using StringBuffer instead of String concatenation --------- //
        StringBuffer buffer = new StringBuffer();
        ms1 = System.currentTimeMillis();
        for(int i=0; i<str.length(); i++)
            for(int j=0; j<=i; j++)
                buffer.append(str.charAt(j));
        ms2 = System.currentTimeMillis();

        System.out.println("approx time taken : " + (ms2 - ms1) + " ms");
        System.out.println(buffer);

        // ---------- using StringBuilder instead of StringBuffer --------- //
        StringBuilder builder = new StringBuilder();
        ms1 = System.currentTimeMillis();
        for(int i=0; i<str.length(); i++)
            for(int j=0; j<=i; j++)
                builder.append(str.charAt(j));
        ms2 = System.currentTimeMillis();

        System.out.println("approx time taken : " + (ms2 - ms1) + " ms");
        System.out.println(builder);
    }
}
