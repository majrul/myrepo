package com.jpmc.training.day2.abstraction;

public enum LogLevel {

    INFO, WARNING, DEBUG, ERROR;
}
