package com.jpmc.training.day2.abstraction;

public class TestLogger {
    public static void main(String[] args) {
        Logger logger = new Logger();
        logger.log("Some message", LogLevel.INFO);
        logger.log("Some message", LogLevel.ERROR);
        logger.log("Another message");
    }
}
