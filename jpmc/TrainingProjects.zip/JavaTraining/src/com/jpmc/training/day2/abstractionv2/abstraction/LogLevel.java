package com.jpmc.training.day2.abstractionv2.abstraction;

public enum LogLevel {

    INFO, WARNING, DEBUG, ERROR;
}
