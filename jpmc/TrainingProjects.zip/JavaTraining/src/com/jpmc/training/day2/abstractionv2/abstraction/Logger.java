package com.jpmc.training.day2.abstractionv2.abstraction;

public class Logger {

    public void log(String message) {
        log(message, LogLevel.INFO);
    }

    public void log(String message, LogLevel level) {

    }
}
