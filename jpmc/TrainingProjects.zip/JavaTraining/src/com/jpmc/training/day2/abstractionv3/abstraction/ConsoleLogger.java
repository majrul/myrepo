package com.jpmc.training.day2.abstractionv3.abstraction;

import java.util.Date;

public class ConsoleLogger extends Logger {

    @Override
    public void log(String message, LogLevel level) {
        Date now = new Date();
        switch (level) {
            case INFO:
                System.out.println("[INFO] ["+now+"] "+message);
                break;
            case DEBUG:
                System.out.println("[DEBUG] ["+now+"] "+message);
                break;
            case WARNING:
                System.out.println("[WARN] ["+now+"] "+message);
                break;
            case ERROR:
                System.out.println("[ERROR] ["+now+"] "+message);
        }
    }
}
