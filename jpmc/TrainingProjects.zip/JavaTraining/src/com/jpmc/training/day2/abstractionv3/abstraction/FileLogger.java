package com.jpmc.training.day2.abstractionv3.abstraction;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

public class FileLogger extends Logger {

    @Override
    public void log(String message, LogLevel level) {
        try {
            FileWriter fw = new FileWriter("app.log", true);
            Date now = new Date();
            switch (level) {
                case INFO:
                    fw.write("[INFO] [" + now + "] " + message + "\n");
                    break;
                case DEBUG:
                    fw.write("[DEBUG] [" + now + "] " + message + "\n");
                    break;
                case WARNING:
                    fw.write("[WARN] [" + now + "] " + message + "\n");
                    break;
                case ERROR:
                    fw.write("[ERROR] [" + now + "] " + message + "\n");
            }
            fw.close(); //should be in finally
        } catch (IOException e) {
            //as of now empty
        }
    }
}
