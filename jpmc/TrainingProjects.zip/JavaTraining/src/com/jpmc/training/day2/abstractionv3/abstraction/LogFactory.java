package com.jpmc.training.day2.abstractionv3.abstraction;

public class LogFactory {

    public static Logger getLoggerInstance() {
        FileLogger logger = new FileLogger();
        return logger;
    }
}
