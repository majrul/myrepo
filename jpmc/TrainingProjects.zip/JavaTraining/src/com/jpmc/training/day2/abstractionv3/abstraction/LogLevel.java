package com.jpmc.training.day2.abstractionv3.abstraction;

public enum LogLevel {

    INFO, WARNING, DEBUG, ERROR;
}
