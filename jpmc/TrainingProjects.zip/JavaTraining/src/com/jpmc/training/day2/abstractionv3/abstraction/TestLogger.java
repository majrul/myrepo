package com.jpmc.training.day2.abstractionv3.abstraction;

public class TestLogger {

    public static void main(String[] args) {
        //ConsoleLogger logger = new ConsoleLogger();
        //FileLogger logger = new FileLogger();
        //LogFactory logFactory = new LogFactory();
        Logger logger = LogFactory.getLoggerInstance();
        logger.log("Some message", LogLevel.INFO);
        logger.log("Some message", LogLevel.ERROR);
        logger.log("Another message");
    }
}
