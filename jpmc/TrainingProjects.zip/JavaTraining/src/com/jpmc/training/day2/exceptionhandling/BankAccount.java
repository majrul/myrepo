package com.jpmc.training.day2.exceptionhandling;

import java.util.Scanner;

public class BankAccount {

    private long acno;
    private double balance;

    public BankAccount(long acno, double balance) {
        this.acno = acno;
        this.balance = balance;
    }

    public double withdraw(double amount)  {
        if(amount > balance) {
            RuntimeException e = new RuntimeException("Insufficient Balance!");
            throw e;
        }
        else {
            balance -= amount;
            return balance;
        }
    }

    public static void main(String[] args) {
        /*Scanner s = new Scanner(System.in);
        System.out.println("Enter your name : ");
        String name = s.next();*/

        BankAccount bankAccount = new BankAccount(111111, 5000);
        //try {
            double balanceLeft = bankAccount.withdraw(6000);
            System.out.println("Balance left : " + balanceLeft);
        //}
        //catch (RuntimeException e) {
          //  System.out.println(e.getMessage());
        //}
    }
}
