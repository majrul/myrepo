package com.jpmc.training.day2.interfaces;

public class Launcher {

    public void launch(MobileApplication mobileApp) {
        mobileApp.start();
        mobileApp.pause();
        mobileApp.stop();
    }
}
