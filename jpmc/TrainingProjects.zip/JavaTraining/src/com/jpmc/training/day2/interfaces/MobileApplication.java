package com.jpmc.training.day2.interfaces;

public interface MobileApplication {

    public void start();
    public void pause();
    public void stop();
}
