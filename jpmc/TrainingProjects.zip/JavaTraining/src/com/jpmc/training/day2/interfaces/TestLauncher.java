package com.jpmc.training.day2.interfaces;

public class TestLauncher {

    public static void main(String[] args) {
        MyMobileApplication myMobileApp = new MyMobileApplication();
        Launcher launcher = new Launcher();
        launcher.launch(myMobileApp);
    }
}