package com.jpmc.training.day3.collections;

import com.jpmc.training.day3.objectclass.Person;

import java.util.*;

public class Example1 {

    public static void main(String[] args) {
        //<> angular brace notation is called as Generics in Java
        ArrayList<String> list1 = new ArrayList<>();
        //list1.add(100); //this will not work
        list1.add("Java");
        list1.add("Oracle");
        list1.add(".NET");
        list1.add("Java");

        //for each loop
        for(String str : list1)
            System.out.println(str);

        ArrayList<Person> list2 = new ArrayList<>();
        list2.add(new Person("Majrul",99));
        list2.add(new Person("John",99));
        list2.add(new Person("Smith",99));

        //list2.sort()
        for(Person p : list2)
            System.out.println(p);


        HashSet<String> set1 = new HashSet<>();
        set1.add("Java");
        set1.add("Oracle");
        set1.add(".NET");
        set1.add("Java");
        for(String str : set1)
            System.out.println(str);

        HashSet<Person> set2 = new HashSet<>();
        set2.add(new Person("Majrul",99));
        set2.add(new Person("John",99));
        set2.add(new Person("Smith",99));
        set2.add(new Person("Majrul",99));

        for(Person p : set2)
            System.out.println(p);

        //sorting
        TreeSet<Integer> set3 = new TreeSet<>();
        set3.add(10);
        set3.add(30);
        set3.add(20);
        set3.add(70);
        set3.add(60);
        set3.add(50);
        for(Integer no : set3)
            System.out.println(no);

        //inner class
        class PersonAgeComparator implements Comparator<Person> {
            @Override
            public int compare(Person o1, Person o2) {
                return o1.getAge() - o2.getAge();
            }
        }
        class PersonNameComparator implements Comparator<Person> {
            @Override
            public int compare(Person o1, Person o2) {
                return o1.getName().compareTo(o2.getName());
            }
        }
        class PersonComparator implements Comparator<Person> {
            @Override
            public int compare(Person o1, Person o2) {
                int order = o1.getName().compareTo(o2.getName());
                if(order == 0)
                    order = o1.getAge() - o2.getAge();
                return order;
            }
        }

        PersonAgeComparator pc1 = new PersonAgeComparator();
        TreeSet<Person> set4 = new TreeSet<>(pc1);
        set4.add(new Person("Majrul",39));
        set4.add(new Person("John",49));
        set4.add(new Person("Smith",29));
        set4.add(new Person("Jack",59));
        for(Person p : set4)
            System.out.println(p);


        HashMap<String,Person> map1 = new HashMap<>();
        map1.put("10.10.10.1", new Person("Majrul", 99));
        map1.put("10.10.10.2", new Person("John", 99));
        map1.put("10.10.10.3", new Person("Smith", 99));
        map1.put("10.10.10.4", new Person("Jack", 99));
        map1.put("10.10.10.1", new Person("Ted", 99));

        System.out.println("=================");
        Person p = map1.get("10.10.10.1");
        System.out.println(p);




    }
}
