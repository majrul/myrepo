package com.jpmc.training.day3.collections;

import java.util.HashMap;

public class UserManager {

    private HashMap<String,String> users = new HashMap<>();

    public UserManager() {
        //KEY,VALUE. IN THIS EXAMPLE KEY IS USERNAME AND VALUE IS PASSWORD
        users.put("majrul","123");
        users.put("john","456");
        users.put("smith","789");
        users.put("jack","000");
    }

    public boolean isValidUser(String username, String password) {
        if(users.containsKey(username))
            if(users.get(username).equals(password))
                return true;
        return false;
    }

    public static void main(String[] args) {
        UserManager mgr = new UserManager();
        boolean b = mgr.isValidUser("majrul","456");
        System.out.println(b);
    }

}
