package com.jpmc.training.day3.collections;

import java.util.ArrayList;

public class UserService {

    private ArrayList<User> users = new ArrayList<>();

    public UserService() {
        users.add(new User("majrul","123",false));
        users.add(new User("john","456",true));
        users.add(new User("smith","789",true));
        users.add(new User("jack","000",true));
    }

    public boolean isValidUser(String username, String password) {
        for(User user : users) {
            if(user.getUsername().equals(username) &&
                user.getPassword().equals(password) &&
                user.isActive())
                    return true;
        }
        return false;
    }

    public static void main(String[] args) {
        UserService userService = new UserService();
        boolean b = userService.isValidUser("john", "456");
        System.out.println(b);
    }
}
