package com.jpmc.training.day3.objectclass;

public class TestPerson {

    public static void main(String[] args) {
        Person p1 = new Person("Majrul", 99);
        System.out.println(p1.getAge());
        System.out.println(p1.getName() + " , " + p1.getAge());
        System.out.println(p1); //What will this print?

        Person p2 = new Person("Majrul", 99);
        System.out.println(p1 == p2); //reference/address comparison
        System.out.println(p1.equals(p1)); //value/data comparison

        System.out.println(p1.hashCode());
        System.out.println(p2.hashCode());

        p1 = null;
        p2 = null;

        System.gc();

        /*int x = 10;
        int y = 10;
        System.out.println(x == y);
        System.out.println(x.equals(y));*/


    }
}
