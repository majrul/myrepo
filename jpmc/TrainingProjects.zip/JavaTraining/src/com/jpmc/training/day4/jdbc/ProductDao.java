package com.jpmc.training.day4.jdbc;

import javax.xml.crypto.Data;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

//Data Access Object
public class ProductDao {

    public void add(Product product) throws DataAccessException {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/trainingdb" , "scott" , "tiger");
            String sql = "insert into product values(?,?,?,?)";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, product.getId());
            stmt.setString(2, product.getName());
            stmt.setDouble(3, product.getPrice());
            stmt.setInt(4, product.getQuantity());
            stmt.executeUpdate();
        }
        catch(SQLException e) {
            throw new DataAccessException("Problem while adding a product", e);
        }
        finally {
            try { stmt.close(); } catch (Exception e) { }
            try { conn.close(); } catch (Exception e) { }
        }
    }

    public void update(Product product) throws DataAccessException {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/trainingdb" , "scott" , "tiger");
            String sql = "update product set name = ?, price = ?, quantity = ? where id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, product.getName());
            stmt.setDouble(2, product.getPrice());
            stmt.setInt(3, product.getQuantity());
            stmt.setInt(4, product.getId());
            int count = stmt.executeUpdate();
            if(count == 0)
                throw new DataAccessException("Some problem. No row got updated in the db!");
        }
        catch(SQLException e) {
            throw new DataAccessException("Problem while updating a product", e);
        }
        finally {
            try { stmt.close(); } catch (Exception e) { }
            try { conn.close(); } catch (Exception e) { }
        }
    }

    public List<Product> fetchAllProducts() throws DataAccessException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/trainingdb" , "scott" , "tiger");
            String sql = "select * from product";
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            ArrayList<Product> products = new ArrayList<>();
            while(rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setQuantity(rs.getInt("quantity"));
                products.add(product);
            }
            return products;
        }
        catch(SQLException e) {
            throw new DataAccessException("Problem while fetching products", e);
        }
        finally {
            try { rs.close(); } catch (Exception e) { }
            try { stmt.close(); } catch (Exception e) { }
            try { conn.close(); } catch (Exception e) { }
        }
    }
}
