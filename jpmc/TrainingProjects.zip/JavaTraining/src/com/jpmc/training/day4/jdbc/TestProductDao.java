package com.jpmc.training.day4.jdbc;

import java.util.List;

public class TestProductDao {

    public static void main(String[] args) {
        try {
            /*Product product =
                    new Product(1, "Nokia 6600", 4500, 99);
            ProductDao dao = new ProductDao();
            //dao.add(product);
            dao.update(product);*/

            ProductDao dao = new ProductDao();
            List<Product> products = dao.fetchAllProducts();
            for(Product product : products)
                System.out.println(product.getId()+","+product.getName()+","+product.getPrice()+","+product.getQuantity());

        }
        catch(DataAccessException e) {
            e.printStackTrace();
        }
    }
}
