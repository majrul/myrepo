package com.jpmc.training.day5.threading;

public class Example1 {

    //inner class
    class Task1 implements Runnable {
        @Override
        public void run() {
            for(int i=0; i<100000; i++) {
                System.out.println("i is " + i);
                //Thread.yield();
                try { Thread.sleep(100); } catch(Exception e) { }
            }
        }
    }

    class Task2 implements Runnable {
        @Override
        public void run() {
            for(int j=0; j<100000; j++) {
                System.out.println("j is " + j);
                //Thread.yield();
                try { Thread.sleep(100); } catch(Exception e) { }
            }
        }
    }

    void launch() {
        Task1 task1 = new Task1();
        Thread th1 = new Thread(task1);
        Task2 task2 = new Task2();
        Thread th2 = new Thread(task2);
        //th1.setPriority(10);
        //th2.setPriority(1);
        th1.start();
        th2.start();
    }

    public static void main(String[] args) {
        Example1 ex1 = new Example1();
        ex1.launch();
    }
}
