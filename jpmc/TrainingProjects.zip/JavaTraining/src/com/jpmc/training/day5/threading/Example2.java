package com.jpmc.training.day5.threading;

class BankAccount {
    int acno;
    double balance;

    BankAccount(int acno, double balance) {
        this.acno = acno;
        this.balance = balance;
    }

    synchronized void withdraw(double amount) {
        try {
            Thread.sleep(100);
            if(amount < balance) {
                Thread.sleep(100);
                balance -= amount;
                Thread.sleep(100);
                System.out.println("Balance left " + balance);
            }
            else
                System.out.println("Insufficient Balance!");
        }
        catch (Exception e)  { } //empty catch not recommended
    }
}

class Transaction implements Runnable {

    BankAccount bankAccount;

    Transaction(BankAccount bankAccount) {
        this.bankAccount = bankAccount;
    }

    @Override
    public void run() {
        bankAccount.withdraw(5000);
    }
}

public class Example2 {

    public static void main(String[] args) {
        BankAccount bankAccount = new BankAccount(1111, 6000);
        Transaction tx1 = new Transaction(bankAccount);
        Transaction tx2 = new Transaction(bankAccount);
        Thread th1 = new Thread(tx1);
        Thread th2 = new Thread(tx2);
        th1.start();
        th2.start();
    }
}
