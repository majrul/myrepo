package com.jpmc.training.io;

import java.io.*;

/**
 * This program copies the content of file to another file
 *
 * @author Majrul
 */
public class CopyFile {

    public static void main(String[] args) {
        FileInputStream file1 = null;
        FileOutputStream file2 = null;
        try {
            file1 = new FileInputStream("sample.zip");
            file2 = new FileOutputStream("copyofsample.zip");

            int ch = 0;
            while (true) {
                ch = file1.read();
                if (ch == -1) //EOF
                    break;
                file2.write(ch);
            }
            System.out.println("File copied successfully!");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try { file1.close(); } catch(Exception e) { }
            try { file2.close(); } catch(Exception e) { }
        }
    }
}
