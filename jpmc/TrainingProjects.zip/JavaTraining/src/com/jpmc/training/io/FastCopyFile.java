package com.jpmc.training.io;

import java.io.*;

/**
 * This program copies the content of file to another file using buffering
 *
 * @author Majrul
 */
public class FastCopyFile {

    public static void main(String[] args) {
        FileInputStream file1 = null;
        FileOutputStream file2 = null;
        BufferedInputStream buffer1 = null;
        BufferedOutputStream buffer2 = null;
        try {
            file1 = new FileInputStream("sample.zip");
            file2 = new FileOutputStream("copyofsample.zip");
            buffer1 = new BufferedInputStream(file1 , 1024*16);
            buffer2 = new BufferedOutputStream(file2 , 1024*16);

            int ch = 0;
            while (true) {
                ch = buffer1.read();
                if (ch == -1) //EOF
                    break;
                buffer2.write(ch);
            }
            System.out.println("File copied successfully!");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try { buffer1.close(); } catch(Exception e) { }
            try { buffer2.close(); } catch(Exception e) { }
            try { file1.close(); } catch(Exception e) { }
            try { file2.close(); } catch(Exception e) { }
        }
    }
}
