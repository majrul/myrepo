package com.jpmc.training.io;

import java.io.*;

/**
 * This program copies the content of file to another file using buffering
 *
 * @author Majrul
 */
public class FastCopyTextFile {

    public static void main(String[] args) {
        FileReader file1 = null;
        FileWriter file2 = null;
        BufferedReader buffer1 = null;
        BufferedWriter buffer2 = null;
        try {
            file1 = new FileReader("sample.txt");
            file2 = new FileWriter("copyofsample.txt");
            buffer1 = new BufferedReader(file1 , 1024*16);
            buffer2 = new BufferedWriter(file2 , 1024*16);

            String line = null;
            while(true) {
                line = buffer1.readLine();
                if(line == null) //EOF
                    break;
                buffer2.write(line.toUpperCase());
                buffer2.newLine();
            }

            System.out.println("File copied successfully!");
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try { buffer1.close(); } catch(Exception e) { }
            try { buffer2.close(); } catch(Exception e) { }
            try { file1.close(); } catch(Exception e) { }
            try { file2.close(); } catch(Exception e) { }
        }
    }
}
