package com.jpmc.training.io;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Serialization {

    public static void main(String[] args) throws Exception {
        /*FileOutputStream file = new FileOutputStream("emp.txt");
        ObjectOutputStream serializer = new ObjectOutputStream(file);

        Employee emp = new Employee(1001, "Majrul", 10000);
        serializer.writeObject(emp);

        serializer.close();
        file.close();*/

        // now the code for deserialization
        FileInputStream file2 =  new FileInputStream("emp.txt");
        ObjectInputStream deserializer = new ObjectInputStream(file2);

        Employee e = (Employee) deserializer.readObject();
        System.out.println(e.getEmpno()+","+e.getName()+","+e.getSalary());

        deserializer.close();
        file2.close();
    }
}
