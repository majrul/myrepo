package com.jpmc.training.lambda;

import java.util.ArrayList;

interface Printer {
    void print(String document);
}

class DotMatrixPrinter implements Printer {
    @Override
    public void print(String document) {
        System.out.println(document + "printed..");
    }
}

public class LambdaExample {

    public static void main(String[] args) {
        DotMatrixPrinter dm = new DotMatrixPrinter();
        dm.print("abc.txt");

        //inner class
        class InkjetPrinter implements Printer {
            @Override
            public void print(String document) {
                System.out.println(document + "printed..");
            }
        }
        InkjetPrinter ij = new InkjetPrinter();
        ij.print("abc.txt");

        //anonymous inner class
        Printer p = new Printer() {
            @Override
            public void print(String document) {
                System.out.println(document + " printed..");
            }
        };
        p.print("xyz.txt");

        //lambda style implementation of Printer interface
        Printer pr = document -> {
                          System.out.println(document + " printed..");
        };
        pr.print("abc.txt");

        ArrayList<String> list = new ArrayList<>();
        list.add("Java");
        list.add("Oracle");
        list.add(".NET");

        for(String str : list)
            System.out.println(str);

        //lambda style for each
        list.forEach(str -> System.out.println(str));
    }
}
