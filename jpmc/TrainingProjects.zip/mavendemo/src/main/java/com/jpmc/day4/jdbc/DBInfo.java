package com.jpmc.day4.jdbc;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;

public class DBInfo {

    public static void main(String[] args) throws Exception {
        Connection conn = DriverManager.getConnection("jdbc:derby://localhost:1527/trainingdb" , "scott" , "tiger");
        DatabaseMetaData dbms = conn.getMetaData();

        System.out.println("DB Name : " + dbms.getDatabaseProductName());
        System.out.println("DB Version : " + dbms.getDatabaseProductVersion());

        conn.close();
    }
}
